-- ════════════════════════════════════════════════════════════════════
-- Print Portfolio — Row Level Security setup
-- Run this in Supabase Dashboard → SQL Editor, on your project.
-- ════════════════════════════════════════════════════════════════════

-- 1. Enable RLS on both tables (this alone blocks ALL access until
--    policies below are added — safe default: deny-by-default).
alter table families enable row level security;
alter table pages    enable row level security;

-- 2. Public read access — anyone (including the anon key in the
--    browser) can SELECT. This matches your "publicly readable"
--    decision for the portfolio dashboards.
create policy "public can read families"
  on families for select
  using (true);

create policy "public can read pages"
  on pages for select
  using (true);

-- 3. Writes require an authenticated Supabase user (not the anon key).
--    This means: only people who have actually logged in via
--    Supabase Auth (email/password, magic link, or OAuth) can
--    insert/update/delete. The public anon key alone cannot write.
create policy "authenticated can insert families"
  on families for insert
  to authenticated
  with check (true);

create policy "authenticated can update families"
  on families for update
  to authenticated
  using (true);

create policy "authenticated can delete families"
  on families for delete
  to authenticated
  using (true);

create policy "authenticated can insert pages"
  on pages for insert
  to authenticated
  with check (true);

create policy "authenticated can update pages"
  on pages for update
  to authenticated
  using (true);

create policy "authenticated can delete pages"
  on pages for delete
  to authenticated
  using (true);

-- ════════════════════════════════════════════════════════════════════
-- NOTE: as written, this HTML dummy calls db.from('pages').upsert(...)
-- directly from the browser with the anon key — that will now FAIL
-- once these policies are active, because the anon key isn't
-- "authenticated." To let your portfolio editors actually edit,
-- you need to add a login step (Supabase Auth) to the page before
-- writes will work. Ask me and I can add a simple email/magic-link
-- login flow to the HTML.
-- ════════════════════════════════════════════════════════════════════
